# 🚴 5000 KM Challenge — Tracker Vélo

Tracker personnel : **5 000 km + 50 000 m D+** · Suisse Normande 2025

---

## ⚡ Installation en 5 minutes (GitHub Pages)

### Étape 1 — Crée un compte GitHub
→ Va sur **github.com** et crée un compte gratuit (si tu n'en as pas)

### Étape 2 — Crée un nouveau dépôt
1. Clique sur le **+** en haut à droite → **New repository**
2. Nomme-le exactement : `velo-tracker`
3. Coche **"Add a README file"**
4. Clique **Create repository**

### Étape 3 — Uploade les fichiers
1. Dans ton dépôt, clique **Add file → Upload files**
2. Glisse-dépose les 3 fichiers :
   - `index.html`
   - `manifest.json`
   - `icon.svg`
3. Clique **Commit changes**

### Étape 4 — Active GitHub Pages
1. Va dans **Settings** (onglet en haut du dépôt)
2. Dans le menu gauche : **Pages**
3. Sous **Source** : sélectionne **main** → dossier **/ (root)**
4. Clique **Save**
5. Attends 1–2 minutes

### Étape 5 — Ton URL
Ton tracker est maintenant accessible à :
```
https://TON-PSEUDO-GITHUB.github.io/velo-tracker/
```

---

## 📱 Ajouter sur l'écran d'accueil

### iPhone / Safari
1. Ouvre l'URL dans Safari
2. Appuie sur l'icône **Partager** (carré avec flèche)
3. → **Sur l'écran d'accueil**
4. Nomme-le "5000 KM" → **Ajouter**

### Android / Chrome
1. Ouvre l'URL dans Chrome
2. Menu (3 points) → **Ajouter à l'écran d'accueil**
3. Confirme

---

## 💾 Sauvegarde automatique

Toutes tes données (km, D+, FTP, semaine) sont **sauvegardées localement** dans ton téléphone via localStorage. Elles persistent entre les sessions, même sans internet.

Pour mettre à jour : entre tes chiffres → **SAUVEGARDER** 💾

---

## 🔄 Mise à jour depuis Strava

Chaque semaine, note depuis Strava :
- Ton **total km de l'année** (onglet "Mes Stats")
- Ton **total D+ de l'année**

Entre ces deux chiffres dans le tracker → Sauvegarder.

---

## 📊 Fonctionnalités

- ✅ Double barre de progression (KM + D+)
- ✅ Paliers kilométriques et de dénivelé
- ✅ Programme hebdomadaire détaillé (cliquable)
- ✅ Puissances calculées depuis ta FTP en temps réel
- ✅ Zones d'entraînement Z1–Z6
- ✅ Plan 6 phases sur 26 semaines
- ✅ Sauvegarde locale automatique
- ✅ Installable sur écran d'accueil (PWA)
